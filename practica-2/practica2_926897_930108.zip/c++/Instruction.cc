/**
 * @file Instruction.cc
 *
 * @authors
 * Hugo García Sánchez (930108)
 * Óscar Grimal Torres (926897)
 */

#include "Instruction.h"
#include <iostream>

// ==========================================
// CLASES BASE
// ==========================================

std::string Instruction::toString() const
{
    return instructionName;
}

Instruction::Instruction(std::string instName)
    : instructionName(instName) {}

InstructionWithImmediate::InstructionWithImmediate(std::string instName, int immVal)
    : Instruction(instName + " " + std::to_string(immVal)), immediateValue(immVal) {}

// ==========================================
// DEFINICION DE INSTRUCCIONES
// ==========================================

int Add::execute(std::stack<int> &stack) const
{
    int a = stack.top();
    stack.pop();
    int b = stack.top();
    stack.pop();
    stack.push(a + b);
    return -1;
}

int Read::execute(std::stack<int> &stack) const
{
    int value;
    std::cout << "? ";
    std::cin >> value;
    stack.push(value);
    return -1;
}

int Write::execute(std::stack<int> &stack) const
{
    int value = stack.top();
    stack.pop();
    std::cout << value << std::endl;
    return -1;
}

int Push::execute(std::stack<int> &stack) const
{
    stack.push(immediateValue);
    return -1;
}

int Dup::execute(std::stack<int> &stack) const
{
    stack.push(stack.top());
    return -1;
}

int JumpIf::execute(std::stack<int> &stack) const
{
    int value = stack.top();
    stack.pop();
    return value >= 0 ? immediateValue : -1;
}

int Mul::execute(std::stack<int> &stack) const
{
    int a = stack.top();
    stack.pop();
    int b = stack.top();
    stack.pop();
    stack.push(a * b);
    return -1;
}

int Swap::execute(std::stack<int> &stack) const
{
    int a = stack.top();
    stack.pop();
    int b = stack.top();
    stack.pop();
    stack.push(a);
    stack.push(b);
    return -1;
}

int Over::execute(std::stack<int> &stack) const
{
    int a = stack.top();
    stack.pop();
    int b = stack.top();
    stack.push(a);
    stack.push(b);
    return -1;
}